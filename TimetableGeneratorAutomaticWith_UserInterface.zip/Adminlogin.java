import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.*;
import javax.swing.JPasswordField;
import javax.swing.SpringLayout;
import java.awt.Color;
public class Adminlogin extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adminlogin frame = new Adminlogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adminlogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 630, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserName = new JLabel("User Name");
		lblUserName.setBounds(80, 58, 100, 34);
		lblUserName.setFont(new Font("Times New Roman", Font.BOLD, 14));
		contentPane.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(80, 103, 88, 28);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(187, 66, 179, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(187, 174, 89, 23);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
               String username,password;
               username = textField.getText();
               password = passwordField.getText();
               if(username.equals("admin")&&password.equals("admin"))
               {
            	   AdminOptions adminoptions = new AdminOptions();
            	   
            	   adminoptions.setVisible(true);
               }
               else
               {
                JOptionPane.showMessageDialog(null, "Wrong password");        	   
               }
			}
		});
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 16));
		contentPane.add(btnLogin);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(192, 108, 174, 20);
		contentPane.add(passwordField);
	}
}
