
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Faculty
  {
    String name;
    int id;
    
    public void setdetails(int id,String Name)
    {
    	this.id = id;
    	name = Name;
    }
	
	
	
	
	
	
	
	
	
	
  }


