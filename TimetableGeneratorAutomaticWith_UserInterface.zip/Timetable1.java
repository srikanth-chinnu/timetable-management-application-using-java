
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class Timetable1
  {
    int[][][] totaltable = new int [10][5][6];
    int[][][] totalreference=new int [10][5][6];
    String[][][] totalnames=new String[10][5][6];
	int fitness=0;
	
	public void initialise(Timetable1 pop,int num,Section[] section)
	{
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<5;j++)
			{
				for(int k=0;k<6;k++)
				{
					pop.totalnames[i][j][k]=" ";
					pop.totaltable[i][j][k]=0;
					pop.totalreference[i][j][k]=0;
				}
			}
		}
		
		Random ob = new Random();
		int day=0,hour=0,prev1=0,prev2=0,count=0;
		for(int i=0;i<num;i++)
		{
			prev1=0;prev2=0;
			for(int j =0;j<section[i].no_of_courses;j++)
			{
				count=0;
				while(count<3)
				{
			      do
				   {
			    	
				    
				     do
				     {
			  	     day = ob.nextInt(5);
				     }while(day==prev2&&count>=2);
				   }while(day==prev1&&count>=1);
	
			  	   hour = ob.nextInt(5);
				
			       if((pop.totaltable[i][day][hour]==0)&&((section[i].references[j]%10)!=hour))
			        {
			    	  pop.totalnames[i][day][hour]=section[i].names[j];
			    	  pop.totaltable[i][day][hour] = section[i].coursecodes[j];
			    	  pop.totalreference[i][day][hour]=section[i].references[j];
			    	  count++;
			    	  prev2=prev1;
			    	  prev1=day;
			        }
				 }
			     	
			}
			int count1=0;
			prev2=0;
			prev1=0;
			day=0;
			while(count1<3)
			{
				do
				{
				do
				{
				day = ob.nextInt(5);
				}while(day==prev2&&count1>=2);
				}while(day==prev1&&count1>=1);
				
				pop.totalnames[i][day][5]=" ";
				pop.totaltable[i][day][5]=9+count1+1;
				prev2=prev1;
				prev1=day;
				pop.totalreference[i][day][5]=0;
				count1++;
			}
			count1=0;
			
		
		  
		}
		int current;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				for(int p=0;p<5;p++)
				{
				current =pop.totalreference[p][i][j];
				if(current!=0)
				{
				for(int k =0;k<num;k++)
				{
					if(pop.totalreference[k][i][j]==current&&k!=p)
						pop.fitness++;
				}
				}
				}
			}
			
		}
	
		
		
	}
	public void display1(Timetable1[] pop,Section[] section,int no_of_sections,int[] n2)throws IOException
	{
		File file = new File("C:\\Users\\HP MY PC\\workspace\\Files\\sample.txt");
        int z;
		// if file doesnt exists, then create it
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		for(int g=0;g<n2.length;g++)
		{
			z=n2[g];
		bw.write("fitness="+Integer.toString(pop[z].fitness));
		bw.write("\n");
		
		bw.write("Timetable is: \n");
		for(int i =0;i<no_of_sections;i++)
		{
			bw.write(section[i].name1+"   Timetable");
			bw.write("\n     \t8-9\t\t9-10\t\t10-11\t\t11-12\t\t1-2\t\t2-5\n");
			for(int j=0;j<5;j++)
			{
				bw.write("\nday"+Integer.toString(j+1)+"\t");
				for(int k=0;k<6;k++)
				{
					if(pop[z].totaltable[i][j][k]!=0&&pop[z].totalreference[i][j][k]!=0)
					{
						bw.write("CO");
					bw.write(Integer.toString(pop[z].totaltable[i][j][k])+" /"+Integer.toString(pop[z].totalreference[i][j][k])+"\t\t");
					}
					else if(k==5&&pop[z].totaltable[i][j][k]>=10&&pop[z].totaltable[i][j][k]<=12)
					{
						bw.write("CO");
						bw.write("Lab"+Integer.toString(pop[z].totaltable[i][j][k]-9)+"/"+ "  "+"\t\t");	
					}
					else
					{
						bw.write("  000/00\t\t");
					}
				}
					
			}
			bw.write("\n\n");
		}
		
		}
		bw.close();
	}
	/*public int getreference(int num,Section s)
	{
		int j=-1;
		for(int i=0;i<s.no_of_courses;i++)
		{
			if(s.coursecodes[i]==num)
			{
				j=s.references[i];
				break;
			}
		}
		return j;
	}*/
	public int getminfitness(Timetable1[] pop)
	{
		int min=pop[0].fitness;
		
		for(int i=0;i<pop.length;i++)
		{
			if(pop[i].fitness<min)
				min=pop[i].fitness;
		}
		return min;
	}
	
	public int[] getnooffitness(Timetable1[] pop,int num)
	{
		int[] i;
		int k=0;
		for(int j=0;j<pop.length;j++)
		{
			if(num==pop[j].fitness)
				k++;
					
		}
		i=new int[k];
		k=0;
		for(int j=0;j<pop.length;j++)
		{
			if(num==pop[j].fitness)
			{
				i[k]=j;
				k++;
			}
		}
		return i;
	}
	public int getmax(Timetable1[] pop)
	{
		int i=pop[0].fitness,k=0;
		for(int j=1;j<pop.length;j++)
		{
			if(pop[j].fitness>i)
			{
				k=j;
				i=pop[j].fitness;
			}
		}
		return k;
	}
	public Timetable1 crossover(Timetable1[] pop,Section[] section,int no_of_sections,int max)
	{
		Random ob = new Random();
		
		int i,j;
		do
		{
			i=ob.nextInt(10);
		}while(i==max);
		do
		{
			j=ob.nextInt(10);
		}while(j==max||j==i);
		Timetable1 mother,father,child;
		child = new Timetable1();
		if(pop[i].fitness>pop[j].fitness)
		{
			mother=pop[j];
			father=pop[i];
		}
		else
		{
			mother=pop[i];
			father=pop[j];
		}
		for(int p=0;p<no_of_sections;p++)
		{
			for(int q=0;q<5;q++)
			{
				for(int r=0;r<5;r++)
				{
					child.totalnames[p][q][r]=" ";
					child.totaltable[p][q][r]=0;
					child.totalreference[p][q][r]=0;
				}
			}
		}
		int prev2=0,prev1=0,day=0;
		for(int p=0;p<no_of_sections;p++)
		{
			int count1=0;
			prev2=0;
			prev1=0;
			while(count1<3)
			{
				do
				{
				do
				{
				day = ob.nextInt(5);
				}while(day==prev2&&count1>=2);
				}while(day==prev1&&count1>=1);
				
			 child.totalnames[p][day][5]=" ";
				child.totaltable[p][day][5]=9+count1+1;
				prev2=prev1;
				prev1=day;
				child.totalreference[p][day][5]=0;
				count1++;
			}
			count1=0;
		}
	/* int count=0,z;
	 while(count<no_of_sections)
	 {
		 z=ob.nextInt(2);
		 if(z==0)
		 {
			 for(int p=0;p<5;p++)
			 {
				 for(int q=0;q<5;q++)
				 {
					 child.totaltable[count][p][q]=mother.totaltable[count][p][q];
					 child.totalreference[count][p][q]=mother.totalreference[count][p][q];
				 }
			 }
		 }
		 else
		 {
			 for(int p=0;p<5;p++)
			 {
				 for(int q=0;q<5;q++)
				 {
					 child.totaltable[count][p][q]=father.totaltable[count][p][q];
					 child.totalreference[count][p][q]=father.totalreference[count][p][q];
				 }
			 } 
		 }
		 count++;
	 }*/
		int count=0;
		for(int p=0;p<no_of_sections;p++)
		{
			for(int q=0;q<5;q++)
			{
				for(int r=0;r<5;r++)
				{
					if(count==0)
					{
						child.totalnames[p][q][r]=mother.totalnames[p][q][r];
						child.totaltable[p][q][r]=mother.totaltable[p][q][r];
						 child.totalreference[p][q][r]=mother.totalreference[p][q][r];
						 count=(count+1)%2;
					}
					else
					{
						child.totalnames[p][q][r]=father.totalnames[p][q][r];
						 child.totaltable[p][q][r]=father.totaltable[p][q][r];
						 child.totalreference[p][q][r]=father.totalreference[p][q][r];
						 count = (count+1)%2;
					}
				}
			}
		}
		child=mother.repair(child,no_of_sections,section);
	 int current;
		for(int p=0;p<5;p++)
		{
			for(int q=0;q<5;q++)
			{
				for(int r=0;r<no_of_sections;r++)
				{
				current =child.totalreference[r][p][q];
				
				if(current!=0)
				{
				for(int k =0;k<no_of_sections;k++)
				{
					if(child.totalreference[k][p][q]==current&&k!=r)
						child.fitness++;
				}
				}
				}
			}
			
		}
	
	return child;
		
		
		
	}
	public Timetable1 repair(Timetable1 child,int no_of_sections,Section[] section)
	{
		Random ob = new Random();
		int day=0;
		int hour=0;
		int[][] coursecount=new int[no_of_sections][10];
		
		for(int i=0;i<no_of_sections;i++)
		{
			for(int j=0;j<10;j++)
			{
				coursecount[i][j]=0;
			}
		}
		int r;
		int flag=0;
		for(int i=0;i<no_of_sections;i++)
		{
			for(int j=0;j<5;j++)
			{
				for(int k=0;k<5;k++)
				{
					
					r = child.getj(child.totaltable[i][j][k],section[i]);
					if(r!=-1)
				    coursecount[i][r]++;	
				}
			}
		}
		for(int i=0;i<no_of_sections;i++)
		{
			for(int j=0;j<5;j++)
			{
				for(int k=0;k<5;k++)
				{
					r = child.getj(child.totaltable[i][j][k],section[i]);
					if(r!=-1)
					{
					if(coursecount[i][r]>3)
					{
						child.totalnames[i][j][k]=" ";
						child.totaltable[i][j][k]=0;
						child.totalreference[i][j][k]=0;
						coursecount[i][r]--;
					}
					else if(coursecount[i][r]<3)
					{ 
						do
						{
						day = ob.nextInt(5);
						hour= ob.nextInt(5);
						if((child.totaltable[i][day][hour]==0)&&((section[i].references[r]%10)!=hour))
						{
							flag=1;
							child.totalnames[i][day][hour]=section[i].names[r];
							child.totaltable[i][day][hour]=section[i].coursecodes[r];
							child.totalreference[i][day][hour]=section[i].references[r];
							coursecount[i][r]++;
						}
						}while(flag!=1);
						flag=0;
						
					}
					}
				}
			}
		}
		for(int i=0;i<no_of_sections;i++)
		{
			for(int j=0;j<section[i].no_of_courses;j++)
			{
				while(coursecount[i][j]<3)
				{
					day = ob.nextInt(5);
					hour = ob.nextInt(5);
					if((child.totaltable[i][day][hour]==0)&&((section[i].references[j]%10)!=hour))
					{
						child.totalnames[i][day][hour]=section[i].names[j];
						child.totaltable[i][day][hour]=section[i].coursecodes[j];
						child.totalreference[i][day][hour]=section[i].references[j];
						coursecount[i][j]++;
					}
				}
			}
		}
		return child;
		
		
	}
	public int getj(int num,Section s)
	{
		int j=-1;
		for(int i=0;i<s.no_of_courses;i++)
		{
			if(s.coursecodes[i]==num)
			{
				j=i;
				break;
			}
		}
		return j;
	}
	
	
	
	
	
	
	
	
  }


