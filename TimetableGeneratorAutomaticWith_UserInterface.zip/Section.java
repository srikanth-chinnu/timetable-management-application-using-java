
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;



public class Section
  {
     String name1;
     int[][] time_table = new int[5][5];
     int no_of_courses;
     String[] names=new String[10];
     int[] coursecodes =new int[10];
     int[] references = new int[10];
     
     public void setDetails(String name1,int num,int[] arr,int[] no,String[] na)
     {
    	 this.name1 = name1;
    	 no_of_courses = num;
    	// coursecodes = new int[num];
    	 for(int i=0;i<num;i++)
    	 {
    		 names[i]=na[i];
    		 references[i] = no[i];
    		 coursecodes[i] = arr[i];
    	 }
 
     }
	
	
	
	
	
	
	
	
	
	
	
  }
