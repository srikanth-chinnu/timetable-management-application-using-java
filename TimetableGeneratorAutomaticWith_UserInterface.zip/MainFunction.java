import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class MainFunction{

	    public void main3(String sectionnames[],int no_of_courses[],int zq)throws IOException
	    {
	    	Scanner sc = new Scanner(System.in);
	    	int generations=0;
	    	int no_of_sections=zq,noofcourses;
	    	int[][] coursecodes;
	    	int[][] references;
	    	String nsection;
	    	int nooffaculty,id1;
	        String n1;
	    	
	    	/*Faculty[] faculty = new Faculty[nooffaculty];
	    	
	    	System.out.println("enter faculty details:");
	    	
	    	for(int i=0;i<nooffaculty;i++)
	    	{
	    		System.out.println("enter name and reference number");
	    		sc.nextLine();
	    		n1 = sc.nextLine();
	    		id1 = sc.nextInt();
	    		faculty[i] = new Faculty();
	    		faculty[i].setdetails(id1,n1);
	    	}*/
	    	
	    	//System.out.println("enter number of sections:");
	    	no_of_sections = zq;
	    	coursecodes = new int[no_of_sections][];
	    	references = new int[no_of_sections][];
	    	String[] na=new String[10];
	    	Section[] section = new Section[no_of_sections];
	    	int count=0;
	    	for(int i=0;i<no_of_sections;i++)
	    	{
	    		//System.out.println("enter no of courses for section"+i);
	    		noofcourses = no_of_courses[i];
	    		coursecodes[i] = new int[noofcourses];
	    		references[i] = new int[noofcourses];
	    		//System.out.println("enter course name,course codes and reference of faculty:");
	    		for(int j=0;j<noofcourses;j++)
	    		{
	    			count++;
	    			//sc.nextLine();
	    			na[j]=" ";
	    			coursecodes[i][j] = (i+2)*100+j;
	    			if(i%2==0&&i!=0&&count%2!=0)
	    			{
	    				references[i][j]=references[i-1][j];
	    			}
	    			else if(i%2!=0&&i!=0&&count%2==0)
	    			{
	    				references[i][j]=references[i-1][j];
	    			}
	    			else
	    			{
	    			references[i][j] = (i+2)*10+j;
	    			}
	    		
	    		}
	    		count=0;
	    		//System.out.println("enter name of section"+i);
	    		//sc.nextLine();
	    		nsection = sectionnames[i];
	    		try
	    		{
	    			section[i] = new Section();
	    		section[i].setDetails(nsection,noofcourses,coursecodes[i],references[i],na);
	    		}
	    		catch(NullPointerException e)
	    		{
	    			System.out.println("error");
	    		}
	    		
	    	}
	    		
	    	
	     
	    	int population_size = 10;
	    	Timetable1[] population = new Timetable1[10];
	    	
	    	for(int i=0;i<population_size;i++)
	    	{
	    		population[i] = new Timetable1();
	    		population[i].initialise(population[i],no_of_sections,section);
	    	}
	    	/*for(int i=0;i<10;i++)
	    	{
	    	population[i].display1(population[i],section,no_of_sections);
	    	}*/
	    	int min_fitness,max;
	    	Timetable1 newtable;
	    	int s=0;
	    	do
	    	{
	         min_fitness=population[0].getminfitness(population);
	        int[] n2=population[0].getnooffitness(population,min_fitness);
	        s++;
	                
	        if(min_fitness==0)
	        {
	        	
	        	//System.out.println("the perfect timetables are:\n");
	        	//for(int i=0;i<n2.length;i++)
	        	//{
	        		//int q=n2[i];
	        	   
	        	   
	        		population[0].display1(population,section,no_of_sections,n2);
	        	   
	        	   
	        	
	        }
	        else
	        {
	          for(int i=0;i<(population_size-n2.length);i++)
	          {
	        	  max = population[0].getmax(population);
	        	  newtable = population[0].crossover(population,section,no_of_sections,max);
	        	  population[max]=newtable;
	          }
	          generations++;
	        }
	        if(s>100000)
	        {
	        	System.out.println("\n the perfect timetables are:");
	        	//for(int i=0;i<n2.length;i++)
	        	//{
	        		//int q=n2[i];
	        		population[0].display1(population,section,no_of_sections,n2);
	        	//}
	        	min_fitness=0;
	        	
	        }
	        
	    	}while(min_fitness!=0);
	    	
	    	
	    	
	    	
	    sc.close();	
	    	
	    }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	  }



