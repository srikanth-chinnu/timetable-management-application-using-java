The user must have eclipse or netbeans software in order to use this application

After extracting files from the zip file import the whole project into eclipse or netbeans software
  
compile "Timetable.java"