import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class Timetableviewer extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Timetableviewer frame = new Timetableviewer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Timetableviewer() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 474);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(102, 204, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDevelopers = new JLabel("Developers:");
		lblDevelopers.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblDevelopers.setBounds(31, 30, 140, 42);
		contentPane.add(lblDevelopers);
		
		JLabel lblYuvarajCb = new JLabel("Yuvaraj C.B.");
		lblYuvarajCb.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblYuvarajCb.setBounds(31, 99, 118, 31);
		contentPane.add(lblYuvarajCb);
		
		JLabel lblMsrikanth = new JLabel("M.Srikanth");
		lblMsrikanth.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblMsrikanth.setBounds(242, 104, 104, 21);
		contentPane.add(lblMsrikanth);
		
		JLabel lblNewLabel = new JLabel("V.Santosh Kumar");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(439, 104, 153, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblIvSem = new JLabel("IV SEM CSE");
		lblIvSem.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblIvSem.setBounds(203, 189, 251, 85);
		contentPane.add(lblIvSem);
		
		JLabel lblNitkSurathkal = new JLabel("NITK Surathkal");
		lblNitkSurathkal.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNitkSurathkal.setBounds(189, 283, 242, 31);
		contentPane.add(lblNitkSurathkal);
	}
}
