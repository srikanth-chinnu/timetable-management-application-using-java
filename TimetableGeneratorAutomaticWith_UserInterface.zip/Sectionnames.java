import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.GridLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Sectionnames extends JFrame {

	private JPanel contentPane;
	private JTextField txtNull;
	private JTextField txtNull_1;
	private JTextField txtNull_2;
	private JTextField txtNull_3;
	private JTextField txtNull_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JLabel label;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField txtNull_5;
	private JTextField textField_13;
	private JTextField txtNull_6;
	private JTextField textField_15;
	private JTextField txtNull_7;
	private JTextField txtNull_8;
	private JButton btnNext;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sectionnames frame = new Sectionnames(5);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sectionnames(int num) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 792, 486);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 2, 0, 0));
		
		JLabel lblPleaseLeaveExtra = new JLabel("Please leave extra fields displayed empty");
		contentPane.add(lblPleaseLeaveExtra);
		
		label = new JLabel("");
		contentPane.add(label);
		
		JLabel lblSectionNames = new JLabel("Section Names");
		lblSectionNames.setHorizontalAlignment(SwingConstants.CENTER);
		lblSectionNames.setFont(new Font("Times New Roman", Font.BOLD, 14));
		contentPane.add(lblSectionNames);
		
		JLabel lblNoOfCourses = new JLabel("No Of Courses");
		lblNoOfCourses.setHorizontalAlignment(SwingConstants.CENTER);
		lblNoOfCourses.setFont(new Font("Times New Roman", Font.BOLD, 14));
		contentPane.add(lblNoOfCourses);
		
		txtNull = new JTextField();
		txtNull.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtNull.setText("null");
		contentPane.add(txtNull);
		txtNull.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setText("0");
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		txtNull_1 = new JTextField();
		txtNull_1.setText("null");
		contentPane.add(txtNull_1);
		txtNull_1.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setText("0");
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		txtNull_2 = new JTextField();
		txtNull_2.setText("null");
		contentPane.add(txtNull_2);
		txtNull_2.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setText("0");
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		txtNull_3 = new JTextField();
		txtNull_3.setText("null");
		contentPane.add(txtNull_3);
		txtNull_3.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setText("0");
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		txtNull_4 = new JTextField();
		txtNull_4.setText("null");
		contentPane.add(txtNull_4);
		txtNull_4.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setText("0");
		contentPane.add(textField_10);
		textField_10.setColumns(10);
		
		txtNull_5 = new JTextField();
		txtNull_5.setText("null");
		contentPane.add(txtNull_5);
		txtNull_5.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setText("0");
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		txtNull_6 = new JTextField();
		txtNull_6.setText("null");
		contentPane.add(txtNull_6);
		txtNull_6.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setText("0");
		contentPane.add(textField_11);
		textField_11.setColumns(10);
		
		txtNull_7 = new JTextField();
		txtNull_7.setText("null");
		contentPane.add(txtNull_7);
		txtNull_7.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setText("0");
		contentPane.add(textField_13);
		textField_13.setColumns(10);
		
		txtNull_8 = new JTextField();
		txtNull_8.setText("null");
		contentPane.add(txtNull_8);
		txtNull_8.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setText("0");
		contentPane.add(textField_15);
		textField_15.setColumns(10);
		
		btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int i=0;
				String[] sectionn = new String[10];
				int[] n = new int[10];
				sectionn[0] = txtNull.getText();
				sectionn[1] = txtNull_1.getText();
				sectionn[2] = txtNull_2.getText();
				sectionn[3] = txtNull_3.getText();
				sectionn[4] = txtNull_4.getText();
				sectionn[5] = txtNull_5.getText();
				sectionn[6] = txtNull_6.getText();
				sectionn[7] = txtNull_7.getText();
				sectionn[8] = txtNull_8.getText();
				n[0] = Integer.parseInt(textField_5.getText());
				n[1] = Integer.parseInt(textField_6.getText());
				n[2] = Integer.parseInt(textField_7.getText());
				n[3] = Integer.parseInt(textField_8.getText());
				n[4] = Integer.parseInt(textField_10.getText());
				n[5] = Integer.parseInt(textField_9.getText());
				n[6] = Integer.parseInt(textField_11.getText());
				n[7] = Integer.parseInt(textField_13.getText());
				n[8] = Integer.parseInt(textField_15.getText());
				MainFunction call = new MainFunction();
				try
				{
				call.main3(sectionn,n,num);
				}
				catch(Exception e)
				{
					//JOptionPane.showMessageDialog(null, e);
					Timetablelist timet = new Timetablelist();
					timet.setVisible(true);
				}
				Timetablelist list2 = new Timetablelist();
				list2.setVisible(true);
			}
		});
		btnNext.setIcon(new ImageIcon("C:\\Users\\HP MY PC\\Pictures\\Button-Next-icon.png"));
		btnNext.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(btnNext);
	}
}
