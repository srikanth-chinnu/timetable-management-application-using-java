import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Window.Type;
import java.awt.Toolkit;

public class Timetable {

	private JFrame frmAutomaticTimetableGenerator;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Timetable window = new Timetable();
					window.frmAutomaticTimetableGenerator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Timetable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAutomaticTimetableGenerator = new JFrame();
		frmAutomaticTimetableGenerator.setFont(new Font("Times New Roman", Font.ITALIC, 16));
		frmAutomaticTimetableGenerator.setTitle("Automatic Timetable Generator");
		frmAutomaticTimetableGenerator.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\HP MY PC\\Pictures\\download (4).jpg"));
		frmAutomaticTimetableGenerator.getContentPane().setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		frmAutomaticTimetableGenerator.getContentPane().setForeground(Color.BLACK);
		frmAutomaticTimetableGenerator.setBounds(100, 100, 604, 434);
		frmAutomaticTimetableGenerator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAutomaticTimetableGenerator.getContentPane().setLayout(null);
		
		JButton btnAdmin = new JButton("Admin");
		btnAdmin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			}
		});
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Adminlogin adminlogin=new Adminlogin();
				adminlogin.setVisible(true);
				
			}
		});
		btnAdmin.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnAdmin.setBounds(167, 51, 146, 48);
		frmAutomaticTimetableGenerator.getContentPane().add(btnAdmin);
		
		JButton btnNewButton = new JButton("User");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			UserFrame userlogin = new UserFrame();
			
			userlogin.setVisible(true);
			
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(167, 144, 146, 48);
		frmAutomaticTimetableGenerator.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Credits");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Timetableviewer tt = new Timetableviewer();
				tt.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton_1.setBounds(167, 229, 146, 48);
		frmAutomaticTimetableGenerator.getContentPane().add(btnNewButton_1);
	}
}
